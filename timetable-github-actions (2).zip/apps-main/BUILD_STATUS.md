# Timetable build status

- Version 0.3.0. **The .wp2app has NOT been built yet**: this environment has no rustc/cargo, `.sdk/` is empty and github.com is unreachable.
- Static fixes only (not compiled): clock ticking on event timeout, glyphs outside the watch font, list action indexing, auto-capital first letter.
- `make check` (store manifests) can be run with plain Python.
- To build: push to GitHub, Actions -> "Build timetable app" -> artifact `timetable-wp2app`, or locally `make doctor && make build APP=timetable` -> `target/timetable.wp2app`.
