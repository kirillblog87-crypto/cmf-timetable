# Build the timetable app with GitHub Actions

This repository includes `.github/workflows/build-timetable.yml`.

After the project files are pushed to a GitHub repository:
1. Open the repository on GitHub.
2. Open the **Actions** tab.
3. Select **Build timetable app**.
4. Press **Run workflow**.
5. When the run finishes successfully, open the run and download the `timetable-wp2app` artifact.

The workflow builds `apps/timetable` using the SDK revision pinned in `Makefile`.
