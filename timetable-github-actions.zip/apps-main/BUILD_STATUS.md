# Timetable build status

- `make check` passed for all store manifests, including `timetable`.
- The timetable app source includes the built-in Russian on-watch keyboard and editable lesson names/times.
- The `.wp2app` package has not been built in this environment: `rustc`, `cargo`, `resvg`, and the pinned SDK checkout are unavailable.
- Fetching the SDK from GitHub was attempted but failed because DNS/network access to github.com is unavailable.

On a computer with the prerequisites listed in README.md, run:

```sh
make doctor
make build APP=timetable
```

Expected package path after a successful build: `target/timetable.wp2app`.
